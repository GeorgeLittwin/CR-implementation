from torch.utils.data import Dataset, DataLoader
from PMLBDataset import PMLBDataset


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Titanic(PMLBDataset):
    strname = 'Titanic'
    base_folder = 'UCIDatasets'

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Titanic, self).__init__(root, 'titanic', train=train, validation=validation, download=download)


if __name__ == '__main__':
    a = Titanic('../UCI', train=True, download=False)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
