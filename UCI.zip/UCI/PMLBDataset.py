import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from zipfile import ZipFile
from pmlb import fetch_data
from sklearn.model_selection import train_test_split

import socket

hostname = socket.gethostname()
if "fair" in hostname:
    ccdir = '/private/home/wolf/specialize/biodatacache'
else:
    ccdir = './biodatacache'


def loadSplits(path='.'):
    with open(os.path.join(path, 'conxuntos.dat'), 'r') as f:
        train_line, test_line = f.readlines()

    train_line = [int(k) for k in train_line.split() if k.isdigit()]
    test_line = [int(k) for k in test_line.split() if k.isdigit()]

    return train_line, test_line


def createlabels(targets):
    uniques = np.unique(targets)
    d = {}
    for i, uni in enumerate(uniques):
        d[uni] = i

    return np.array([d[x] for x in targets])


# -- Test set performance (final 1044 examples, first 3133 used for training):
class PMLBDataset(Dataset):
    def __init__(self, root, dataset='car', train=True, validation=False, download=False, val_size=0.15):
        self.root = root
        self.base_folder = os.path.join(self.root, self.base_folder, self.strname)

        data, targets = fetch_data(dataset, return_X_y=True, local_cache_dir=ccdir)
        targets = createlabels(targets)
        split_train, split_test = loadSplits(os.path.join(self.root, 'Splits/', self.strname))
        self.train_data = data[split_train, :].astype(np.float32)
        self.train_labels = targets[split_train].astype(np.int64)

        self.train_data, self.validation_data, self.train_labels, self.validation_labels = train_test_split(
            self.train_data, self.train_labels, test_size=val_size, random_state=42)

        self.test_data = data[split_test, :].astype(np.float32)
        self.test_labels = targets[split_test].astype(np.int64)

        self.train_size = len(split_train)
        self.validation_size = len(self.validation_data)
        self.test_size = len(split_test)
        print 'train_size: {}\t validation_size: {}\t test_size {}'.format(len(self.train_data),
                                                                           len(self.validation_data),
                                                                           len(self.test_data))

        means, stds = self.train_data.mean(0), self.train_data.std(0)
        stds[stds == 0] = 1

        self.train_data = (self.train_data - means) / stds
        self.validation_data = (self.validation_data - means) / stds
        self.test_data = (self.test_data - means) / stds

        self.train = train
        self.validation = validation
        self.i_dim = self.train_data.shape[1]
        self.num_classes = max(targets) + 1
        assert not (self.train == True and self.validation == True), "can't use both validation and train together!"
        assert self.num_classes, 'Please add the number of classes'
        self.train_size = len(self.train_data)
        self.validation_size = len(self.validation_data)
        self.test_size = len(self.test_data)

    def __getitem__(self, index):
        if self.train:
            data, target = self.train_data[index], self.train_labels[index]
        elif self.validation:
            data, target = self.validation_data[index], self.validation_labels[index]
        else:
            data, target = self.test_data[index], self.test_labels[index]

        return data, target

    def __len__(self):
        if self.train:
            return self.train_size
        elif self.validation:
            return self.validation_size
        else:
            return self.test_size

    def __str__(self):
        return self.strname

    def input_dim(self):
        return self.i_dim
