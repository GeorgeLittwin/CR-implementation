from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return int(x)


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Pendigits(UCIDataset):
    strname = 'Pendigits'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/pendigits/'
    filename = ['pendigits.tra', 'pendigits.tes']
    num_classes = 10

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[10] = lambda x: classs(x)

        super(Pendigits, self).__init__(root,
                                        converters=converters,
                                        delimiter=',',
                                        train=train,
                                        validation=validation,
                                        download=download,
                                        use_split=True,
                                        given_val=False)


if __name__ == '__main__':
    a = Pendigits('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
