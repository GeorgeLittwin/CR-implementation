from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset, loadSplits
from sklearn.model_selection import train_test_split
import os
import numpy as np
import pandas as pd

val = {'A': 1, 'C': 2, 'G': 3, 'T': 4}
classes = {'EI': 0, 'IE': 1, 'N': 2}

def valdict(k):
    if k in val:
        return val[k]
    else:
        return 0


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Molec_biol_splice(UCIDataset):
    strname = 'Molec_biol_splice'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/molecular-biology/splice-junction-gene-sequences/'
    filename = ['splice.data']
    num_classes = 3  # weird because dataset has 3

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=True):

        self.root = root
        self.base_folder = os.path.join(self.root, self.base_folder, self.strname)
        if download:
            self.download()

        data = []
        targets = []
        with open(os.path.join(self.base_folder, self.filename[0]), 'r') as f:
            allfile = f.readlines()
            for line in allfile:
                c, id, code = line.split()
                targets.append(classes[c[:-1]])
                data.append([valdict(l) for l in code])

        targets = np.array(targets)
        data = np.array(data)

        if use_split:
            split_train, split_test = loadSplits(os.path.join(self.root, 'Splits/', self.strname))
            print 'in', len(split_train), len(split_test)
            self.train_data = data[split_train, :].astype(np.float32)
            self.train_labels = targets[split_train].astype(np.int64)
            self.test_data = data[split_test, :].astype(np.float32)
            self.test_labels = targets[split_test].astype(np.int64)

            self.train_size = len(split_train)
            self.test_size = len(split_test)
        else:
            self.train_data = data[:self.train_size, :].astype(np.float32)
            self.train_labels = targets[:self.train_size].astype(np.int64)
            self.test_data = data[self.train_size:, :].astype(np.float32)
            self.test_labels = targets[self.train_size:].astype(np.int64)

        self.train_data, self.validation_data, self.train_labels, self.validation_labels = train_test_split(
            self.train_data, self.train_labels, test_size=0.15, random_state=42)

        means, stds = self.train_data.mean(0), self.train_data.std(0)
        stds[stds == 0] = 1

        self.train_data = (self.train_data - means) / stds
        self.validation_data = (self.validation_data - means) / stds
        self.test_data = (self.test_data - means) / stds

        self.train = train
        self.validation = validation
        self.i_dim = self.train_data.shape[1]
        assert not (self.train == True and self.validation == True), "can't use both validation and train together!"
        assert self.num_classes, 'Please add the number of classes'
        self.train_size = len(self.train_data)
        self.validation_size = len(self.validation_data)
        self.test_size = len(self.test_data)


if __name__ == '__main__':
    a = Molec_biol_splice('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
