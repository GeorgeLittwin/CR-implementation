import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from UCIDataset import UCIDataset
from collections import Counter

reload(sys)
sys.setdefaultencoding("utf-8")

workclass = {'Private': 0 + 1, 'Self-emp-not-inc': 1 + 1, 'Self-emp-inc': 2 + 1,
             'Federal-gov': 3 + 1, 'Local-gov': 4 + 1, 'State-gov': 5 + 1, 'Without-pay': 6 + 1, 'Never-worked': 7 + 1}
education = {'Bachelors': 0 + 1, 'Some-college': 1 + 1, '11th': 2 + 1, 'HS-grad': 3 + 1, 'Prof-school': 4 + 1,
             'Assoc-acdm': 5 + 1,
             'Assoc-voc': 6 + 1, '9th': 7 + 1, '7th-8th': 8 + 1,
             '12th': 9 + 1, 'Masters': 10 + 1, '1st-4th': 11 + 1, '10th': 12 + 1, 'Doctorate': 13 + 1,
             '5th-6th': 14 + 1, 'Preschool': 15 + 1}
marital = {'Married-civ-spouse': 0 + 1, 'Divorced': 1 + 1, 'Never-married': 2 + 1, 'Separated': 3 + 1, 'Widowed': 4 + 1,
           'Married-spouse-absent': 5 + 1,
           'Married-AF-spouse': 6 + 1}
occupation = {'Tech-support': 0 + 1, 'Craft-repair': 1 + 1, 'Other-service': 2 + 1, 'Sales': 3 + 1,
              'Exec-managerial': 4 + 1,
              'Prof-specialty': 5 + 1,
              'Handlers-cleaners': 6 + 1, 'Machine-op-inspct': 7 + 1, 'Adm-clerical': 8 + 1, 'Farming-fishing': 9 + 1,
              'Transport-moving': 10 + 1,
              'Priv-house-serv': 11 + 1, 'Protective-serv': 12 + 1, 'Armed-Forces': 13 + 1}
relationship = {'Wife': 0 + 1, 'Own-child': 1 + 1, 'Husband': 2 + 1, 'Not-in-family': 3 + 1, 'Other-relative': 4 + 1,
                'Unmarried': 5 + 1}
race = {'White': 0 + 1, 'Asian-Pac-Islander': 1 + 1, 'Amer-Indian-Eskimo': 2 + 1, 'Other': 3 + 1, 'Black': 4 + 1}
sex = {'Male': 0 + 1, 'Female': 1 + 1}
country = {'United-States': 0 + 1, 'Cambodia': 1 + 1, 'England': 2 + 1, 'Puerto-Rico': 3 + 1, 'Canada': 4 + 1,
           'Germany': 5 + 1,
           'Outlying-US(Guam-USVI-etc)': 6 + 1, 'India': 7 + 1, 'Japan': 8 + 1, 'Greece': 9 + 1, 'South': 10 + 1,
           'China': 11 + 1, 'Cuba': 12 + 1,
           'Iran': 13 + 1, 'Honduras': 14 + 1, 'Philippines': 15 + 1, 'Italy': 16 + 1, 'Poland': 17 + 1,
           'Jamaica': 18 + 1, 'Vietnam': 19 + 1,
           'Mexico': 20 + 1, 'Portugal': 21 + 1, 'Ireland': 22 + 1, 'France': 23 + 1, 'Dominican-Republic': 24 + 1,
           'Laos': 25 + 1,
           'Ecuador': 26 + 1, 'Taiwan': 27 + 1, 'Haiti': 28 + 1, 'Columbia': 29 + 1, 'Hungary': 30 + 1,
           'Guatemala': 31 + 1, 'Nicaragua': 32 + 1,
           'Scotland': 33 + 1, 'Thailand': 34 + 1, 'Yugoslavia': 35 + 1, 'El-Salvador': 36 + 1,
           'Trinadad&Tobago': 37 + 1, 'Peru': 38 + 1,
           'Hong': 39 + 1, 'Holand-Netherlands': 40 + 1}

classes = {'<=50K': 0, '>50K': 1}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Adult(UCIDataset):
    strname = 'Adult'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/adult/'
    filename = ['adult.data', 'adult.test']
    train_size = 32561
    test_size = 16281
    skip_rows = [None, [0]]
    num_classes = 2

    def __init__(self, root='.', train=True, validation=False, download=False):
        converters = {1: lambda x: akb(workclass, x),
                      3: lambda x: akb(education, x),
                      5: lambda x: akb(marital, x),
                      6: lambda x: akb(occupation, x),
                      7: lambda x: akb(relationship, x),
                      8: lambda x: akb(race, x),
                      9: lambda x: akb(sex, x),
                      13: lambda x: akb(country, x),
                      14: lambda x: classs(x)}
        super(Adult, self).__init__(root,
                                    converters=converters,
                                    delimiter=',',
                                    encoding='utf-8',
                                    train=train,
                                    validation=validation,
                                    download=download,
                                    usecols=[1, 3, 5, 6, 7, 8, 9, 13, 14],
                                    use_split=True,given_val=False
                                    )

    def binconvert(self, x):
        if x == 'yes':
            return 1
        else:
            return -1


if __name__ == '__main__':
    a = Adult('.', train=True, download=True)
    print Counter(a.train_labels)
    l = DataLoader(a, batch_size=8)
    # print next(enumerate(l))
