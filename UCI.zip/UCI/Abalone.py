from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Abalone(UCIDataset):
    strname = 'Abalone'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/abalone/'
    filename = ['abalone.data']
    train_size = 3133
    test_size = 1044
    genderconvert = {'M': 0, 'F': 1, 'I': 2}
    num_classes = 3

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):

        converters = {0: self.convert,
                      8: self.classconvert}

        super(Abalone, self).__init__(root,
                                      converters=converters,
                                      delimiter=',',
                                      train=train,
                                      validation=validation,
                                      download=download,
                                      use_split=True)

    def convert(self, x):
        if x == 'M':
            return -1
        elif x == 'F':
            return 0
        else:
            return 1

    def classconvert(self, x):
        x = int(x)
        if x < 9:
            return 0
        elif x < 11:
            return 1
        else:
            return 2


if __name__ == '__main__':
    a = Abalone('.', train=True, download=False)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
