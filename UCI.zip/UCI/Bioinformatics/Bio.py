from pmlb import fetch_data, dataset_names
import numpy as np

from torch.utils.data import Dataset


class BioClass(Dataset):
    def __init__(self,dataset):
        data, labels = fetch_data(dataset, return_X_y=True)

        self.i_dim = data.shape[1]
        self.num_classes = np.max(labels + 1)



    def __getitem__(self, index):
        if self.train:
            data, target = self.train_data[index], self.train_labels[index]
        else:
            data, target = self.test_data[index], self.test_labels[index]

        return data, target

    def __len__(self):
        if self.train:
            return self.train_size
        else:
            return self.test_size

    def __str__(self):
        return self.strname

    def input_dim(self):
        return self.i_dim


if __name__ == '__main__':
    a = BioClass('adult')
    print a.num_classes