from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
from UCIDataset import loadSplits
import numpy as np
import os
import pandas as pd
from sklearn.model_selection import train_test_split

def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return int(x) - 1


class Steel_plates(UCIDataset):
    strname = 'Steel_plates'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/00198/'
    filename = ['Faults.NNA']
    num_classes = 7

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=True):
        self.root = root
        self.base_folder = os.path.join(self.root, self.base_folder, self.strname)
        if download:
            self.download()
        t_csv = []

        for filename in self.filename:
            d = pd.read_csv(os.path.join(self.base_folder, filename), header=None, encoding=None, delim_whitespace=True)
            d = d.fillna(value=0)
            t_csv.append(d)
        data = pd.concat(t_csv)

        targets = np.argmax(data.iloc[:, -7:].values, axis=1)
        data = data.iloc[:, :-7].values

        if use_split:
            split_train, split_test = loadSplits(os.path.join(self.root, 'Splits/', self.strname))
            self.train_data = data[split_train, :].astype(np.float32)
            self.train_labels = targets[split_train].astype(np.int64)
            self.test_data = data[split_test, :].astype(np.float32)
            self.test_labels = targets[split_test].astype(np.int64)

            self.train_size = len(split_train)
            self.test_size = len(split_test)
        else:
            self.train_data = data[:self.train_size, :].astype(np.float32)
            self.train_labels = targets[:self.train_size].astype(np.int64)
            self.test_data = data[self.train_size:, :].astype(np.float32)
            self.test_labels = targets[self.train_size:].astype(np.int64)



        self.train_data, self.validation_data, self.train_labels, self.validation_labels = train_test_split(
            self.train_data, self.train_labels, test_size=0.15, random_state=42)


        means, stds = self.train_data.mean(0), self.train_data.std(0)
        stds[stds == 0] = 1

        self.train_data = (self.train_data - means) / stds
        self.validation_data = (self.validation_data - means) / stds
        self.test_data = (self.test_data - means) / stds

        self.train = train
        self.validation = validation
        self.i_dim = self.train_data.shape[1]
        assert not (self.train == True and self.validation == True), "can't use both validation and train together!"
        assert self.num_classes, 'Please add the number of classes'
        self.train_size = len(self.train_data)
        self.validation_size = len(self.validation_data)
        self.test_size = len(self.test_data)

        print 'train_size: {}\t validation_size: {}\t test_size {}'.format(len(self.train_data), len(self.validation_data),
                                                                   len(self.test_data))

if __name__ == '__main__':
    a = Steel_plates('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
