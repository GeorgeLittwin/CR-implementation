from torch.utils.data import Dataset, DataLoader
from PMLBDataset import PMLBDataset


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Chess_krvkp(PMLBDataset):
    strname = 'Chess_krvkp'
    base_folder = 'UCIDatasets'

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Chess_krvkp, self).__init__(root, 'chess', train=train, validation=validation, download=download)


if __name__ == '__main__':
    a = Chess_krvkp('../UCI', train=False,validation=True, download=False)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
