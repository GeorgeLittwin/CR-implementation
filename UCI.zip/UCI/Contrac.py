from torch.utils.data import Dataset, DataLoader
from PMLBDataset import PMLBDataset


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Contrac(PMLBDataset):
    strname = 'Contrac'
    base_folder = 'UCIDatasets'

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Contrac, self).__init__(root, 'contraceptive', train=train, validation=validation, download=download)


if __name__ == '__main__':
    a = Contrac('../UCI', train=True, download=False)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
