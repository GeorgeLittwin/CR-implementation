from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
from UCIDataset import loadSplits, download_url
from zipfile import ZipFile
import numpy as np
import os
import pandas as pd
from sklearn.model_selection import train_test_split


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)



def classs(x):
    return int(x) - 1


class Cardiotocography_10clases(UCIDataset):
    strname = 'Cardiotocography_10clases'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/00193/'
    filename = ['CTG.csv']
    num_classes = 10

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[43] = classs

        super(Cardiotocography_10clases, self).__init__(root,
                                                       converters=converters,
                                                       delimiter=',',
                                                       usecols=range(10,31) + [43],
                                                       na_values='?',
                                                       train=train,
                                                       validation=validation,
                                                       download=download,
                                                       use_split=True)


if __name__ == '__main__':
    a = Cardiotocography_10clases('.', train=True, download=True)
    l = DataLoader(a, batch_size=200)
    print next(enumerate(l))
