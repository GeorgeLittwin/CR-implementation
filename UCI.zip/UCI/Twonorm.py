from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
from UCIDataset import loadSplits, download_url
from zipfile import ZipFile
import numpy as np
import os
import pandas as pd
from sklearn.model_selection import train_test_split


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return int(x)


class Twonorm(UCIDataset):
    strname = 'Twonorm'
    base_folder = 'UCIDatasets'
    url = 'ftp://ftp.cs.toronto.edu/pub/neuron/delve/data/tarfiles/'
    filename = ['Dataset.data']
    num_classes = 2

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=True):
        super(Twonorm, self).__init__(root,
                                      delim_whitespace=True,
                                      train=train,
                                      validation=validation,
                                      download=download,
                                      use_split=True)


if __name__ == '__main__':
    a = Twonorm('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
