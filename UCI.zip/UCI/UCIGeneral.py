import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from zipfile import ZipFile
from sklearn.model_selection import train_test_split


class UCIDatasetGeneral(Dataset):
    def __init__(self, root, dataset, train=True, validation=False, fold=0):
        self.root = root
        self.strname = dataset
        super(Dataset, self).__init__()
        dir = os.path.join(root, dataset)
        raw_data = pd.read_csv(os.path.join(dir, '{}_py.dat'.format(dataset)), header=None).values.astype(np.float32)
        raw_labels = pd.read_csv(os.path.join(dir, 'labels_py.dat'), header=None).values.astype(np.int64)
        train_fold = pd.read_csv(os.path.join(dir, 'folds_py.dat'), header=None).values[:, fold].astype(bool)
        val_fold = pd.read_csv(os.path.join(dir, 'validation_folds_py.dat'), header=None).values[:, fold].astype(bool)
        test_fold = (1 - (train_fold + val_fold)).astype(bool)



        raw_labels = np.squeeze(raw_labels)
        self.train_data, self.train_labels = raw_data[train_fold], raw_labels[train_fold]
        self.validation_data, self.validation_labels = raw_data[val_fold], raw_labels[val_fold]
        self.test_data, self.test_labels = raw_data[test_fold], raw_labels[test_fold]

        self.train_size = len(self.train_data)
        self.validation_size = len(self.validation_data)
        self.test_size = len(self.test_data)

        self.train = train
        self.validation = validation
        self.i_dim = self.train_data.shape[1]
        self.num_classes = np.max(raw_labels) + 1

        assert (np.max(raw_labels) - np.min(raw_labels)) + 1 == self.num_classes

    def __getitem__(self, index):
        if self.train:
            data, target = self.train_data[index], self.train_labels[index]
        elif self.validation:
            data, target = self.validation_data[index], self.validation_labels[index]
        else:
            data, target = self.test_data[index], self.test_labels[index]

        return data, target

    def __len__(self):
        if self.train:
            return self.train_size
        elif self.validation:
            return self.validation_size
        else:
            return self.test_size

    def __str__(self):
        return self.strname

    def input_dim(self):
        return self.i_dim


if __name__ == '__main__':
    a = UCIDatasetGeneral('/home/rotmanmi/Downloads/data', 'bank')
