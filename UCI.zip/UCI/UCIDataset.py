import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from zipfile import ZipFile
from sklearn.model_selection import train_test_split


def loadSplits(path='.'):
    with open(os.path.join(path, 'conxuntos.dat'), 'r') as f:
        train_line, test_line = f.readlines()

    train_line = [int(k) for k in train_line.split() if k.isdigit()]
    test_line = [int(k) for k in test_line.split() if k.isdigit()]

    return train_line, test_line


def download_url(url, root, filename):
    from six.moves import urllib

    fpath = os.path.join(root, filename)

    try:
        os.makedirs(root)
    except OSError as e:
        if e.errno == errno.EEXIST:
            pass
        else:
            raise

    # downloads file
    if os.path.isfile(fpath):
        print('Using downloaded and verified file: ' + fpath)
    else:
        print('Downloading ' + url + ' to ' + fpath)
        urllib.request.urlretrieve(os.path.join(url, filename), fpath)


# -- Test set performance (final 1044 examples, first 3133 used for training):
class UCIDataset(Dataset):
    def __init__(self, root, converters=None, delimiter='\t', encoding=None, train=True, validation=False,
                 download=False, usecols=None,
                 use_split=False, na_values=None, delim_whitespace=False, class_first=False, given_val=False, val_size=0.15):
        self.root = root
        self.base_folder = os.path.join(self.root, self.base_folder, self.strname)
        if download:
            self.download()

        if not hasattr(self, 'skip_rows'):
            self.skip_rows = [None] * len(self.filename)

        t_csv = []

        for filename, skip in zip(self.filename, self.skip_rows):
            if delim_whitespace:
                d = pd.read_csv(os.path.join(self.base_folder, filename), header=None,
                                converters=converters, encoding=encoding, usecols=usecols, na_values=na_values,
                                skiprows=skip, delim_whitespace=delim_whitespace)
            else:
                d = pd.read_csv(os.path.join(self.base_folder, filename), header=None, delimiter=delimiter,
                                converters=converters, encoding=encoding, usecols=usecols, na_values=na_values,
                                skiprows=skip)
            d = d.fillna(value=0)
            t_csv.append(d)
        data = pd.concat(t_csv)

        if class_first:
            targets = data.iloc[:, 0].values.astype(np.int64)
            data = data.iloc[:, 1:].values.astype(np.float32)
        else:
            targets = data.iloc[:, -1].values.astype(np.int64)
            data = data.iloc[:, :-1].values.astype(np.float32)
        if use_split:
            split_train, split_test = loadSplits(os.path.join(self.root, 'Splits/', self.strname))
            self.train_data = data[split_train, :].astype(np.float32)
            self.train_labels = targets[split_train].astype(np.int64)
            self.test_data = data[split_test, :].astype(np.float32)
            self.test_labels = targets[split_test].astype(np.int64)

            self.train_size = len(split_train)
            self.test_size = len(split_test)
        else:
            self.train_data = data[:self.train_size, :].astype(np.float32)
            self.train_labels = targets[:self.train_size].astype(np.int64)
            self.test_data = data[self.train_size:, :].astype(np.float32)
            self.test_labels = targets[self.train_size:].astype(np.int64)

        if given_val:
            self.validation_data = self.test_data
            self.validation_labels = self.test_labels

            mask = np.ones(data.shape[0], dtype=bool)
            mask[split_train + split_test] = False

            self.test_data = data[mask]
            self.test_labels = targets[mask]
        else:
            self.train_data, self.validation_data, self.train_labels, self.validation_labels = train_test_split(
                self.train_data, self.train_labels, test_size=val_size, random_state=42)

        print 'train_size: {}\t validation_size: {}\t test_size {}'.format(len(self.train_data),
                                                                           len(self.validation_data),
                                                                           len(self.test_data))

        means, stds = self.train_data.mean(0), self.train_data.std(0)
        stds[stds == 0] = 1

        self.train_data = (self.train_data - means) / stds
        self.validation_data = (self.validation_data - means) / stds
        self.test_data = (self.test_data - means) / stds

        self.train = train
        self.validation = validation
        self.i_dim = self.train_data.shape[1]
        assert not (self.train == True and self.validation == True), "can't use both validation and train together!"
        assert self.num_classes, 'Please add the number of classes'
        self.train_size = len(self.train_data)
        self.validation_size = len(self.validation_data)
        self.test_size = len(self.test_data)

    def download(self):
        if hasattr(self, 'filename_zipped'):
            for filename in self.filename_zipped:
                download_url(self.url, self.base_folder, filename)
                try:
                    if filename.endswith('.Z') or filename.endswith('.z'):
                        os.system('uncompress -f {}'.format(os.path.join(self.base_folder, filename)))

                    else:
                        f = ZipFile(os.path.join(self.base_folder, filename), 'r')
                        f.extractall(self.base_folder + '/')
                        f.close()
                except:
                    pass
        else:
            for filename in self.filename:
                download_url(self.url, self.base_folder, filename)

    def __getitem__(self, index):
        if self.train:
            data, target = self.train_data[index], self.train_labels[index]
        elif self.validation:
            data, target = self.validation_data[index], self.validation_labels[index]
        else:
            data, target = self.test_data[index], self.test_labels[index]

        return data, target

    def __len__(self):
        if self.train:
            return self.train_size
        elif self.validation:
            return self.validation_size
        else:
            return self.test_size

    def __str__(self):
        return self.strname

    def input_dim(self):
        return self.i_dim
