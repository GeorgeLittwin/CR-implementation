from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os

classes = {'not_recom': 0, 'recommend': 1, 'very_recom': 2, 'priority': 3, 'spec_prior': 4}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Nursery(UCIDataset):
    strname = 'Nursery'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/nursery/'
    filename = ['nursery.data']
    num_classes = 5

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):

        alldata = []
        with open(os.path.join(root, self.base_folder, self.strname, 'valores_entradas.dat'), 'r') as f:
            filedata = f.readlines()
            for line in filedata:
                alldata.append(line.split())

        converters = {}

        converters[0] = lambda x: {k: v for k, v in zip(alldata[0],range(1, len(alldata[0]) + 1))}[x]
        converters[1] = lambda x: {k: v for k, v in zip(alldata[1], range(1, len(alldata[1]) + 1))}[x]
        converters[2] = lambda x: {k: v for k, v in zip(alldata[2], range(1, len(alldata[2]) + 1))}[x]
        converters[3] = lambda x: {k: v for k, v in zip(alldata[3], range(1, len(alldata[3]) + 1))}[x]
        converters[4] = lambda x: {k: v for k, v in zip(alldata[4], range(1, len(alldata[4]) + 1))}[x]
        converters[5] = lambda x: {k: v for k, v in zip(alldata[5], range(1, len(alldata[5]) + 1))}[x]
        converters[6] = lambda x: {k: v for k, v in zip(alldata[6], range(1, len(alldata[6]) + 1))}[x]
        converters[7] = lambda x: {k: v for k, v in zip(alldata[7], range(1, len(alldata[7]) + 1))}[x]
        converters[8] = lambda x: classs(x)

        super(Nursery, self).__init__(root,
                                      converters=converters,
                                      delimiter=',',
                                      train=train,
                                      validation=validation,
                                      download=download,
                                      use_split=True)


if __name__ == '__main__':
    a = Nursery('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
