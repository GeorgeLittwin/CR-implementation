from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
from UCIDataset import loadSplits, download_url
from zipfile import ZipFile
import numpy as np
import os
import pandas as pd
from sklearn.model_selection import train_test_split


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


classes = {'Move-Forward': 0, 'Slight-Right-Turn': 1, 'Sharp-Right-Turn': 2, 'Slight-Left-Turn': 3}


def classs(x):
    return classes[x]


class Wall_following(UCIDataset):
    strname = 'Wall_following'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/00194/'
    filename = ['sensor_readings_24.data']
    num_classes = 4

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[24] = classs

        super(Wall_following, self).__init__(root,
                                             converters=converters,
                                             delimiter=',',
                                             train=train,
                                             validation=validation,
                                             download=download,
                                             use_split=True)

if __name__ == '__main__':
    a = Wall_following('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
