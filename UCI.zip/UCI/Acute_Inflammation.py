import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from UCIDataset import UCIDataset

reload(sys)
sys.setdefaultencoding("utf-8")


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Acute_Inflammation(UCIDataset):
    strname = 'Acute_Inflammation'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/acute/'
    filename = ['diagnosis.data']
    train_size = 60
    test_size = 60

    def __init__(self, root='.', train=True, validation=False, download=False):

        converters = {0: lambda x: np.float32(x.replace(',', '.')),
                      1: self.binconvert,
                      2: self.binconvert,
                      3: self.binconvert,
                      4: self.binconvert,
                      5: self.binconvert,
                      6: lambda x: max(self.binconvert(x), 0),
                      7: lambda x: max(self.binconvert(x), 0)}
        super(Acute_Inflammation, self).__init__(root,
                                                 converters=converters,
                                                 delimiter='\t',
                                                 encoding='utf-16',
                                                 train=train,
                                                 validation=validation,
                                                 download=download,
                                                 usecols=[0, 1, 2, 3, 4, 5, 6],
                                                 use_split=True)

    def binconvert(self, x):
        if x == 'yes':
            return 1
        else:
            return -1


if __name__ == '__main__':
    a = Acute_Inflammation('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
