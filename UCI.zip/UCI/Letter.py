from torch.utils.data import Dataset, DataLoader
from PMLBDataset import PMLBDataset
from collections import Counter


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Letter(PMLBDataset):
    strname = 'Letter'
    base_folder = 'UCIDatasets'

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Letter, self).__init__(root, 'letter', train=train, validation=validation, download=download)


if __name__ == '__main__':
    a = Letter('../UCI', train=True, download=False)
    print Counter(a.test_labels)
    l = DataLoader(a, batch_size=8)
    # print next(enumerate(l))
