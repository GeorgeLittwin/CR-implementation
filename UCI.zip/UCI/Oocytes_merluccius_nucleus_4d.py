from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os

classes = {'cn': 0, 'sn': 1}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Oocytes_merluccius_nucleus_4d(UCIDataset):
    strname = 'Oocytes_merluccius_nucleus_4d'
    base_folder = 'UCIDatasets'
    url = ''
    filename = ['coocurrencia_1_2_4_8_gris_probability_gris_statistics_5_color_nucleos_R.dat']
    num_classes = 2
    skip_rows = [[0]]

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):

        converters = {}

        converters[42] = lambda x: classs(x)

        super(Oocytes_merluccius_nucleus_4d, self).__init__(root,
                                                            converters=converters,
                                                            delim_whitespace=True,
                                                            train=train,
                                                            validation=validation,
                                                            download=download,
                                                            use_split=True)


if __name__ == '__main__':
    a = Oocytes_merluccius_nucleus_4d('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
