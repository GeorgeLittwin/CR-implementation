from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset

val = {'b': 1, 'o': 2, 'x': 3}
classes = {'draw': 0, 'loss': 1, 'win': 0}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Hill_Valley(UCIDataset):
    strname = 'Hill_Valley'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/hill-valley/'
    filename = ['Hill_Valley_with_noise_Training.data', 'Hill_Valley_with_noise_Testing.data']
    num_classes = 2
    skip_rows = [[0], [0]]

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Hill_Valley, self).__init__(root,
                                          train=train,
                                          delimiter=',',
                                          validation=validation,
                                          download=download,
                                          use_split=True,given_val=False
                                          )


if __name__ == '__main__':
    a = Hill_Valley('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
