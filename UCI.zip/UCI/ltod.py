l = ['unknown','other','failure','success']
print {k: v for k,v in zip(l,range(len(l)))}.__repr__()