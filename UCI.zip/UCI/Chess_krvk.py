import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from UCIDataset import UCIDataset

reload(sys)
sys.setdefaultencoding("utf-8")
val = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}
classes = {'draw': 0, 'zero': 1, 'one': 2, 'two': 3, 'three': 4, 'four': 5, 'five': 6, 'six': 7, 'seven': 8, 'eight': 9,
           'nine': 10, 'ten': 11, 'eleven': 12,
           'twelve': 13, 'thirteen': 14, 'fourteen': 15, 'fifteen': 16, 'sixteen': 17}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Chess_krvk(UCIDataset):
    strname = 'Chess_krvk'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/chess/king-rook-vs-king/'
    filename = ['krkopt.data']
    train_size = 14028
    test_size = 14028
    skip_rows = [None]
    num_classes = 18

    def __init__(self, root='.', train=True, validation=False, download=False):
        converters = {0: lambda x: akb(val, x),
                      2: lambda x: akb(val, x),
                      4: lambda x: akb(val, x),
                      6: lambda x: classs(x)}
        super(Chess_krvk, self).__init__(root,
                                         converters=converters,
                                         delimiter=',',
                                         encoding='utf-8',
                                         train=train,
                                         validation=validation,
                                         download=download,
                                         usecols=range(7),
                                         use_split=True
                                         )

    def binconvert(self, x):
        if x == 'yes':
            return 1
        else:
            return -1


if __name__ == '__main__':
    a = Chess_krvk('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
