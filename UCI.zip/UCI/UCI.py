import sys

from UCIDataset import UCIDataset
from Abalone import Abalone
from Acute_Inflammation import Acute_Inflammation
from Acute_Nephiritis import Acute_Nephiritis
from Adult import Adult
from Chess_krvk import Chess_krvk
from Bank import Bank
from Car import Car
from Chess_krvkp import Chess_krvkp
from Contrac import Contrac
from Letter import Letter
from Magic import Magic
from Mushroom import Mushroom
from Optical import Optical
from Ringnorm import Ringnorm
from Titanic import Titanic
from Waveform import Waveform
from Waveform_Noise import Waveform_Noise
from Connect_4 import Connect_4
from Hill_Valley import Hill_Valley
from Led_Display import Led_Display
from Image_Segmentation import Image_Segmentation
from Miniboone import Miniboone
from Molec_biol_splice import Molec_biol_splice
from Nursery import Nursery
from Oocytes_merluccius_nucleus_4d import Oocytes_merluccius_nucleus_4d
from Oocytes_merluccius_states_2f import Oocytes_merluccius_states_2f
from Ozone import Ozone
from Page_blocks import Page_blocks
from Pendigits import Pendigits
from Plants_margin import Plants_margin
from Plants_shape import Plants_shape
from Plants_texture import Plants_texture
from Semeion import Semeion
from Spambase import Spambase
from Statlog_german_credit import Statlog_german_credit
from Statlog_image import Statlog_image
from Statlog_landsat import Statlog_landsat
from Statlog_shuttle import Statlog_shuttle
from Steel_plates import Steel_plates
from Thyroid import Thyroid
from Twonorm import Twonorm
from Wall_following import Wall_following
from Wine_quality_red import Wine_quality_red
from Wine_quality_white import Wine_quality_white
from Cardiotocography_3clases import Cardiotocography_3clases
from Cardiotocography_10clases import Cardiotocography_10clases
from Yeast import Yeast

reload(sys)
sys.setdefaultencoding("utf-8")

list_of_datasets = {'Abalone': Abalone,
                    # 'Acute_Inflammation': Acute_Inflammation,
                    # 'Acute_Nephiritis': Acute_Nephiritis,
                    'Adult': Adult,
                    'Bank': Bank,
                    'Car': Car,
                    'Cardiotocography_3clases': Cardiotocography_3clases,
                    'Cardiotocography_10clases': Cardiotocography_10clases,
                    'Chess_krvk': Chess_krvk,
                    'Chess_krvkp': Chess_krvkp,
                    'Connect_4': Connect_4,
                    'Contrac': Contrac,
                    'Hill_Valley': Hill_Valley,
                    'Image_Segmentation': Image_Segmentation,
                    'Led_Display': Led_Display,
                    'Letter': Letter,
                    'Magic': Magic,
                    'Miniboone': Miniboone,
                    'Molec_biol_splice': Molec_biol_splice,
                    'Mushroom': Mushroom,
                    'Nursery': Nursery,
                    'Oocytes_merluccius_nucleus_4d': Oocytes_merluccius_nucleus_4d,
                    'Oocytes_merluccius_states_2f': Oocytes_merluccius_states_2f,
                    'Optical': Optical,
                    'Ozone': Ozone,
                    'Page_blocks': Page_blocks,
                    'Pendigits': Pendigits,
                    'Plants_margin': Plants_margin,
                    'Plants_texture': Plants_texture,
                    'Plants_shape': Plants_shape,
                    'Ringnorm': Ringnorm,
                    'Semeion': Semeion,
                    'Spambase': Spambase,
                    'Statlog_german_credit': Statlog_german_credit,
                    'Statlog_image': Statlog_image,
                    'Statlog_landsat': Statlog_landsat,
                    'Statlog_shuttle': Statlog_shuttle,
                    'Steel_plates': Steel_plates,
                    'Thyroid': Thyroid,
                    'Titanic': Titanic,
                    'Twonorm': Twonorm,
                    'Waveform': Waveform,
                    'Wall_following': Wall_following,
                    'Waveform_Noise': Waveform_Noise,
                    'Wine_quality_red': Wine_quality_red,
                    'Wine_quality_white': Wine_quality_white,
                    'Yeast': Yeast
                    }


def getDataset(name, root, train=True, validation=False, download=True):
    assert name in list_of_datasets.keys(), 'Dataset is not in the list of datasets!'
    return list_of_datasets[name](root, train, validation, download)


if __name__ == '__main__':
    print next(enumerate(getDataset('Chess_krvkp', '.', train=True, download=True)))
    print len(list_of_datasets)
