from torch.utils.data import Dataset, DataLoader
from PMLBDataset import PMLBDataset


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Car(PMLBDataset):
    strname = 'Car'
    base_folder = 'UCIDatasets'

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        super(Car, self).__init__(root, 'car', train=train, validation=validation, download=download)


if __name__ == '__main__':
    a = Car('../UCI', train=True, download=False)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
