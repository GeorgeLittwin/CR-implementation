from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return int(x) - 1


class Statlog_shuttle(UCIDataset):
    strname = 'Statlog_shuttle'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/'
    filename = ['shuttle.trn', 'shuttle.tst']
    filename_zipped = ['shuttle.trn.Z', 'shuttle.tst']
    num_classes = 7

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[9] = lambda x: classs(x)

        super(Statlog_shuttle, self).__init__(root,
                                              converters=converters,
                                              delim_whitespace=True,
                                              train=train,
                                              validation=validation,
                                              download=download,
                                              use_split=True,
                                              given_val=False)


if __name__ == '__main__':
    a = Statlog_shuttle('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
