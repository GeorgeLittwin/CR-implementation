from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os



def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)



# -- Test set performance (final 1044 examples, first 3133 used for training):
class Ozone(UCIDataset):
    strname = 'Ozone'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/ozone/'
    filename = ['onehr.data']
    num_classes = 2

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = None


        super(Ozone, self).__init__(root,
                                    converters=converters,
                                    delimiter=',',
                                    train=train,
                                    validation=validation,
                                    na_values='?',
                                    download=download,
                                    use_split=True,
                                    usecols=range(1,74))


if __name__ == '__main__':
    a = Ozone('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
