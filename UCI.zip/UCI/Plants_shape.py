from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace(' ', '')]


classes = {'AcerCampestre': 0,
           'AcerCapillipes': 1,
           'AcerCircinatum': 2,
           'AcerMono': 3,
           'AcerOpalus': 4,
           'AcerPalmatum': 5,
           'AcerPictum': 6,
           'AcerPlatanoids': 7,
           'AcerRubrum': 8,
           'AcerRufinerve': 9,
           'AcerSaccharinum': 10,
           'AlnusCordata': 11,
           'AlnusMaximowiczii': 12,
           'AlnusRubra': 13,
           'AlnusSieboldiana': 14,
           'AlnusViridis': 15,
           'ArundinariaSimonii': 16,
           'BetulaAustrosinensis': 17,
           'BetulaPendula': 18,
           'CallicarpaBodinieri': 19,
           'CastaneaSativa': 20,
           'CeltisKoraiensis': 21,
           'CercisSiliquastrum': 22,
           'CornusChinensis': 23,
           'CornusControversa': 24,
           'CornusMacrophylla': 25,
           'CotinusCoggygria': 26,
           'CrataegusMonogyna': 27,
           'CytisusBattandieri': 28,
           'EucalyptusGlaucescens': 29,
           'EucalyptusNeglecta': 30,
           'EucalyptusUrnigera': 31,
           'FagusSylvatica': 32,
           'GinkgoBiloba': 33,
           'IlexAquifolium': 34,
           'IlexCornuta': 35,
           'LiquidambarStyraciflua': 36,
           'LiriodendronTulipifera': 37,
           'LithocarpusCleistocarpus': 38,
           'LithocarpusEdulis': 39,
           'MagnoliaHeptapeta': 40,
           'MagnoliaSalicifolia': 41,
           'MorusNigra': 42,
           'OleaEuropaea': 43,
           'Phildelphus': 44,
           'PopulusAdenopoda': 45,
           'PopulusGrandidentata': 46,
           'PopulusNigra': 47,
           'PrunusAvium': 48,
           'PrunusXShmittii': 49,
           'PterocaryaStenoptera': 50,
           'QuercusAfares': 51,
           'QuercusAgrifolia': 52,
           'QuercusAlnifolia': 53,
           'QuercusBrantii': 54,
           'QuercusCanariensis': 55,
           'QuercusCastaneifolia': 56,
           'QuercusCerris': 57,
           'QuercusChrysolepis': 58,
           'QuercusCoccifera': 59,
           'QuercusCoccinea': 60,
           'QuercusCrassifolia': 61,
           'QuercusCrassipes': 62,
           'QuercusDolicholepis': 63,
           'QuercusEllipsoidalis': 64,
           'QuercusGreggii': 65,
           'QuercusHartwissiana': 66,
           'QuercusIlex': 67,
           'QuercusImbricaria': 68,
           'QuercusInfectoriasub': 69,
           'QuercusKewensis': 70,
           'QuercusNigra': 71,
           'QuercusPalustris': 72,
           'QuercusPhellos': 73,
           'QuercusPhillyraeoides': 74,
           'QuercusPontica': 75,
           'QuercusPubescens': 76,
           'QuercusPyrenaica': 77,
           'QuercusRhysophylla': 78,
           'QuercusRubra': 79,
           'QuercusSemecarpifolia': 80,
           'QuercusShumardii': 81,
           'QuercusSuber': 82,
           'QuercusTexana': 83,
           'QuercusTrojana': 84,
           'QuercusVariabilis': 85,
           'QuercusVulcanica': 86,
           'QuercusxHispanica': 87,
           'QuercusxTurneri': 88,
           'RhododendronxRussellianum': 89,
           'SalixFragilis': 90,
           'SalixIntergra': 91,
           'SorbusAria': 92,
           'TiliaOliveri': 93,
           'TiliaPlatyphyllos': 94,
           'TiliaTomentosa': 95,
           'UlmusBergmanniana': 96,
           'ViburnumTinus': 97,
           'ViburnumxRhytidophylloides': 98,
           'ZelkovaSerrata': 99}


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Plants_shape(UCIDataset):
    strname = 'Plants_shape'
    base_folder = 'UCIDatasets'
    url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/00241/'
    filename = ['100 leaves plant species/data_Sha_64.txt']
    filename_zipped = ['100%20leaves%20plant%20species.zip']
    num_classes = 100

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[0] = lambda x: classs(x)

        super(Plants_shape, self).__init__(root,
                                            converters=converters,
                                            delimiter=',',
                                            train=train,
                                            validation=validation,
                                            download=download,
                                            use_split=True,
                                            class_first=True)


if __name__ == '__main__':
    a = Plants_shape('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
