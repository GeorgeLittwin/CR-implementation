from UCI import list_of_datasets, getDataset

for ds in list_of_datasets.keys():
    a = getDataset(ds, root='../../UCI', train=True, download=True)
    print ds, a.num_classes
