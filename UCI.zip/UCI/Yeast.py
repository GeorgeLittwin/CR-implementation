from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace(' ', '')]


classes = {'CYT': 0,
           'NUC': 1,
           'MIT': 2,
           'ME3': 3,
           'ME2': 4,
           'ME1': 5,
           'EXC': 6,
           'VAC': 7,
           'POX': 8,
           'ERL': 9}


class Yeast(UCIDataset):
    strname = 'Yeast'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/yeast/'
    filename = ['yeast.data']
    num_classes = 10

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}
        converters[9] = lambda x: classs(x)

        super(Yeast, self).__init__(root,
                                    converters=converters,
                                    delim_whitespace=True,
                                    train=train,
                                    validation=validation,
                                    download=download,
                                    use_split=True,
                                    usecols=range(1, 10))


if __name__ == '__main__':
    a = Yeast('.', train=True, download=True)
    l = DataLoader(a, batch_size=100)
    print next(enumerate(l))
