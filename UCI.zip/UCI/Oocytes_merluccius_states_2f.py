from torch.utils.data import Dataset, DataLoader
from UCIDataset import UCIDataset
import os

classes = {'ac': 0, 'hid': 1, 'v/at': 2}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Oocytes_merluccius_states_2f(UCIDataset):
    strname = 'Oocytes_merluccius_states_2f'
    base_folder = 'UCIDatasets'
    url = ''
    filename = ['lbp_riu_gris_statistics_5_color_estados_R.dat']
    num_classes = 3
    skip_rows = [[0]]

    def __init__(self, root='.', train=True, validation=False, download=False, use_split=False):
        converters = {}

        converters[26] = lambda x: classs(x)

        super(Oocytes_merluccius_states_2f, self).__init__(root,
                                                           converters=converters,
                                                           delim_whitespace=True,
                                                           train=train,
                                                           validation=validation,
                                                           download=download,
                                                           use_split=True)


if __name__ == '__main__':
    a = Oocytes_merluccius_states_2f('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
