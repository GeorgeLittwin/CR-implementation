import sys
import numpy as np
import os
import errno
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import sys
from UCIDataset import UCIDataset

reload(sys)
sys.setdefaultencoding("utf-8")

job = {'management': 3 + 1, 'retired': 9 + 1, 'self-employed': 8 + 1, 'unknown': 1 + 1, 'unemployed': 2 + 1,
       'admin.': 0 + 1,
       'technician': 10 + 1, 'entrepreneur': 5 + 1, 'services': 11 + 1, 'student': 6 + 1, 'housemaid': 4 + 1,
       'blue-collar': 7 + 1}

marital = {'married': 0 + 1, 'divorced': 1 + 1, 'single': 2 + 1}
education = {'unknown': 0 + 1, 'primary': 2 + 1, 'tertiary': 3 + 1, 'secondary': 1 + 1}
default = {'yes': 0 + 1, 'no': 1 + 1}
contact = {'unknown': 0 + 1, 'telephone': 1 + 1, 'cellular': 2}
month = {'mar': 2 + 1, 'feb': 1 + 1, 'aug': 7 + 1, 'sep': 8 + 1, 'apr': 3 + 1, 'jun': 5 + 1, 'jul': 6 + 1, 'jan': 0 + 1,
         'may': 4 + 1, 'nov': 10 + 1, 'dec': 11 + 1,
         'oct': 9 + 1}
poutcome = {'unknown': 0 + 1, 'other': 1 + 1, 'success': 3 + 1, 'failure': 2 + 1}

# check classes again
classes = {'no': 0, 'yes': 1}


def a(n):
    return 2.0 / (len(n) - 1)


def b(n):
    return (1.0 + len(n)) / (1.0 - len(n))


def akb(c, x):
    if x.strip() == '?':
        return 0
    else:
        return a(c) * (c[x.strip()] + 1) + b(c)


def classs(x):
    return classes[x.strip().replace('.', '')]


# -- Test set performance (final 1044 examples, first 3133 used for training):
class Bank(UCIDataset):
    strname = 'Bank'
    base_folder = 'UCIDatasets'
    url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/00222/'
    filename = ['bank.csv']
    filename_zipped = ['bank.zip']
    train_size = 2261
    test_size = 2260
    skip_rows = [[0]]
    num_classes = 2

    def __init__(self, root='.', train=True, validation=False, download=False):
        converters = {1: lambda x: akb(job, x),
                      2: lambda x: akb(marital, x),
                      3: lambda x: akb(education, x),
                      4: lambda x: akb(default, x),
                      6: lambda x: akb(default, x),
                      7: lambda x: akb(default, x),
                      8: lambda x: akb(contact, x),
                      10: lambda x: akb(month, x),
                      15: lambda x: akb(poutcome, x),
                      16: lambda x: classs(x)}
        super(Bank, self).__init__(root,
                                   converters=converters,
                                   delimiter=';',
                                   encoding='utf-8',
                                   train=train,
                                   validation=validation,
                                   download=download,
                                   usecols=range(17),
                                   use_split=True
                                   )

    def binconvert(self, x):
        if x == 'yes':
            return 1
        else:
            return -1


if __name__ == '__main__':
    a = Bank('.', train=True, download=True)
    l = DataLoader(a, batch_size=8)
    print next(enumerate(l))
